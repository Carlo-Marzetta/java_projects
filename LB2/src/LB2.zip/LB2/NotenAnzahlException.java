
public class NotenAnzahlException extends Exception
{
	public NotenAnzahlException()
	{
		super("Zu viele Noteneintr�ge!\nEs k�nnen pro Fach maximal 5 Noten erfasst werden.");
	}
}
