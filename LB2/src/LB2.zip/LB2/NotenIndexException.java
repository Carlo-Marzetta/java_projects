
public class NotenIndexException extends Exception
{
	public NotenIndexException()
	{
		super("Ung�ltiger Indexwert!\nDer Indexwert ist negativ oder gr�sser als 5.");
	}
}
