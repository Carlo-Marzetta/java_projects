/**
  *
  * Stellt einen Notenwert eines Fachs dar.
  * Jede Note ist mit der Laufnummer der P�rfung versehen, also 1 f�r die 
  * 1. Pr�fung, 2 f�r die 2. Pr�fung usw.
  * Der Notwert ist selbsterkl�rend.
  *
  * @version 1.0 vom 29.06.2016
  * @author 
  */

public class Note {
  
  // Anfang Attribute
  private int laufnummer = 0;
  private float notenwert = 1.0f;
  // Ende Attribute
  
  
  /**
  * Erzeugt ein Notenobjekt mit Laufnummer und Notenwert.
  * @param nr die Laufnummer
  * @param note der Notenwert
  */
  public Note(int nr, float note){
    setNotenwert(nr, note);  
  }
  
  /**
  * Liefert die Laufnummer zur Note.
  * @return laufnummer
  */
  public int getLaufnummer() {
    return laufnummer;
  }
  
  /**
  * Liefert den Notenwert
  * @return notenwert  
  */
  public float getNotenwert() {
    return notenwert;
  }
  
  /**
  * Setzt den Notenwert.
  * @param nr die laufnummer der Note
  * @param note der Notenwert
  */
  public void setNotenwert(int nr, float note){
    laufnummer = nr;
    notenwert = note;
  }
    
  
  
  // Ende Methoden
} // end of Note
